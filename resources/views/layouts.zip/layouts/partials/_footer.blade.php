<footer>
  <div class="container-fluid">
    <p class="copyright">&copy; 2020 <a href="https://www.easytinh.com/" target="_blank">Phagna@2020</a>. All Rights Reserved.</p>
  </div>
</footer>