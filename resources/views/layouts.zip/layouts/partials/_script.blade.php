<script src="{{asset('assets/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{asset('assets/vendor/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/vendor/pace/pace.min.js')}}"></script>
<script src="{{asset('assets/scripts/klorofilpro-common.min.js')}}"></script>